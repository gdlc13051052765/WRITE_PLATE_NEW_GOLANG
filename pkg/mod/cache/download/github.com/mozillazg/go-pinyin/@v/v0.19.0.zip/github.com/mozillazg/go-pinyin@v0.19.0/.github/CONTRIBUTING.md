# Contributing


* 发送 Pull Request 时麻烦将目标分支修改为 `develop` 分支。
* 如果是关于单个汉字的拼音有误的 BUG，麻烦前往 [pinyin-data](https://github.com/mozillazg/pinyin-data/issues) 进行反馈。


Thanks for contributing! :heart:
